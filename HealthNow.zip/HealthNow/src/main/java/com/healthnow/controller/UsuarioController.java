package com.healthnow.controller;

import com.healthnow.domain.Usuario;
import com.healthnow.service.UsuarioService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioService usuarioService;

    @GetMapping("/login")
    public String cargarPaginaLogin() {
        return "/login";
    }

    @GetMapping("/registro")
    public String cargarPaginaRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "/registro";
    }

    @PostMapping("/registro")
    public String registrarUsuario(
            @Valid @ModelAttribute("usuario") Usuario usuario,
            BindingResult bindingResult,
            Model model) {

        if (bindingResult.hasErrors()) {
            return "/registro";
        }

        try {
            usuario.setActivo(true);
            usuarioService.registrarUsuario(usuario);

            return "redirect:/login?registroExitoso";

        } catch (DataIntegrityViolationException e) {
            model.addAttribute(
                    "error",
                    "El nombre de usuario, correo o cédula ya está registrado."
            );
            return "/registro";
        }
    }
}