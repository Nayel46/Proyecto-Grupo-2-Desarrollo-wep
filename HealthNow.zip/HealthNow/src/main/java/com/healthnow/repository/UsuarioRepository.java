package com.healthnow.repository;

import com.healthnow.domain.Usuario;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    public Usuario findByUsername(String username);

    public Usuario findByCorreo(String correo);

    public Usuario findByCedula(String cedula);

    public List<Usuario> findByActivoTrue();
}