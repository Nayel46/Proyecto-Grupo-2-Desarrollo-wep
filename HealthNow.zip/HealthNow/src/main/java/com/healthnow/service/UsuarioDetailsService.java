package com.healthnow.service;

import com.healthnow.domain.Usuario;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UsuarioDetailsService implements UserDetailsService {

    private final UsuarioService usuarioService;

    @Override
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException {

        Usuario usuario =
                usuarioService.getUsuarioPorUsername(username);

        if (usuario == null) {
            throw new UsernameNotFoundException(
                "No se encontró el usuario: " + username
            );
        }

        return User.withUsername(usuario.getUsername())
                .password(usuario.getPassword())
                .roles("USER")
                .disabled(!usuario.isActivo())
                .build();
    }
}